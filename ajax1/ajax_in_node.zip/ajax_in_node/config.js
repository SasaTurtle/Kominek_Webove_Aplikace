module.exports = {
    db: {
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'coffe_lmsoft_cz'
    }
  };
  